import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UserComponent } from './user.component';
import { HomeComponent } from './home.component';
import { LoginComponent } from './login.component';
import { RegisterComponent } from './register.component';

import {HttpModule} from '@angular/http';

import { Routes,RouterModule } from '@angular/router';


//路由配置
export const ROUTES: Routes = [
  { path: 'home',
    component: HomeComponent,
    children:[
      {path:'login',component:LoginComponent},
      {path:'register',component:RegisterComponent},
    ]
  },
  { path: 'user', component: UserComponent }
];


@NgModule({
  //声明UserComponent组件
  declarations: [
    AppComponent,UserComponent,HomeComponent,LoginComponent,RegisterComponent
  ],

  //依赖注入
  imports: [
  /*
  RouterModule.forRoot() 方法用于在主模块中定义主要的路由信息，
  通过调用该方法使得我们的主模块可以访问路由模块中定义的所有指令
  */
    BrowserModule,HttpModule,RouterModule.forRoot(ROUTES)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
