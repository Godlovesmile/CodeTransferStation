import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  //template : '<h1>Hello {{message | json}}</h1><user></user>'
  template : `<h1>我是首页内容可以切换路由</h1><h1>{{message | json}}</h1>
              <nav><a routerLink="/home">首页</a><a routerLink="/user">我的</a></nav>
              <router-outlet></router-outlet>`
})
export class AppComponent {
  title = 'app';
  message = {
   provice : '合肥',
   city : '安徽'
  }
}

/*
ng   了解:1.
Angular4知识点 :
  1.绑定属性值 {{}}
  2.使用Angular内置的json管道,显示对象信息
  3.自定义组件
  4.构造函数初始化数据
  5.常用指令简介(最常用的指令是ngIf,ngFor)
  6.事件绑定
  7.Http模块
  8.路由模块简介
*/

//vue-resource    ;  axios   ; fetch
