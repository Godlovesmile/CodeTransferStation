import { Component } from '@angular/core';

@Component({
  selector : 'register',
  template : `<h1>我是注册页面</h1>`
})
export class RegisterComponent {

}
