import { Component } from '@angular/core';
import { Http } from '@angular/http';

import 'rxjs/add/operator/map';

@Component({
  selector : 'home',
  template : `
  <div>
  <h1>我是首页</h1>
  <nav>
    <a routerLink="/home/login">login</a>
    <a routerLink="/home/register">register</a>
  </nav>
  <router-outlet></router-outlet>
  </div>
  `
})
export class HomeComponent {

}
