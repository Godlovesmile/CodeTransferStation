import { Component } from '@angular/core';


//强调 : 使用http模块必须引入
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

//自定义组件
@Component({
  selector : 'user',
  template : `<h2>我的名字是:{{name}},喜欢{{message.hobby}}</h2>
              <button (click)="toggleSkills()">技能显示/隐藏</button>
              <ul *ngIf='showSkills'><li *ngFor="let skill of skills">{{skill.content}}</li></ul>`
})
export class UserComponent {
  name = '';
  message : {};
  showSkills : Boolean;
  skills : any;

  //事件
  toggleSkills() {
    this.showSkills = !this.showSkills;
  };
  //使用构造函数初始化数据
  constructor(http : Http) {
    this.name = '闫理智';
    this.message = {
      sex : '男',
      hobby : '篮球'
    };
    this.showSkills = true;
    //this.skills = ['吃饭','睡觉','打豆豆'];
    http.get(`https://bird.ioliu.cn/joke/rand?type=text`)
        .map(res => res.json())
        .subscribe(data => {
          if(data) console.log(data)
          this.skills = data.data;
        })
  }
}
